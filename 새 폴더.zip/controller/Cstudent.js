exports.main = (req, res) => {
    res.render('index');
};
